create procedure p1(eno emp.empno%type)
is
begin
  update emp set sal = sal + 100 where empno = eno;
  commit;
end;
/

